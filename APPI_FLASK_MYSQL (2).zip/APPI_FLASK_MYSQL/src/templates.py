from flask import Flask, render_template, request, redirect, url_for
import requests

app = Flask(__name__)

# Configuración de la API
API_URL = 'http://localhost:5000'

# Ruta para la página de inicio
@app.route('/')
def index():
    return render_template('index.html')

# Ruta para la página de registro de mascota perdida
@app.route('/registrar-mascota', methods=['GET', 'POST'])
def registrar_mascota():
    if request.method == 'POST':
        data = {
            'tipoDoc': request.form['tipoDoc'],
            'numDoc': request.form['numDoc'],
            'nombreDueño': request.form['nombreDueño'],
            'apellidoDueño': request.form['apellidoDueño'],
            'fechaNacDueño': request.form['fechaNacDueño'],
            'nombreMascota': request.form['nombreMascota'],
            'animal': request.form['animal'],
            'raza': request.form['raza'],
            'direccionPerdida': request.form['direccionPerdida'],
            'distrito': request.form['distrito'],
            'provincia': request.form['provincia']
        }
        response = requests.post(f"{API_URL}/registrarMascotaPerdida", json=data)
        if response.status_code == 200:
            return redirect(url_for('index'))
        else:
            return render_template('registrar_mascota.html', error=response.json()['error'])
    return render_template('registrar_mascota.html')

if __name__ == '__main__':
    app.run(debug=True)
