# app.py
from flask import Flask, request, jsonify

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = (
    'mysql+pymysql://root:rOiOtBQSjUGojZXQVcAukkFPBApVOUuu@junction.proxy.rlwy.net:21172/railway'
)
db_sql.init_app(app)

# Modelo para la base de datos relacional
class Mascota(db_sql.Model):
    id = db_sql.Column(db_sql.Integer, primary_key=True)
    nombre = db_sql.Column(db_sql.String(50), nullable=False)
    tipo = db_sql.Column(db_sql.String(50), nullable=False)
    fecha_perdida = db_sql.Column(db_sql.Date)
    descripcion = db_sql.Column(db_sql.Text)

# Crear la base de datos
with app.app_context():
    db_sql.create_all()

@app.route('/mascotas', methods=['GET', 'POST'])
def mascotas():
    if request.method == 'POST':
        data = request.json
        nueva_mascota = Mascota(
            nombre=data['nombre'],
            tipo=data['tipo'],
            fecha_perdida=data.get('fecha_perdida'),  # opcional
            descripcion=data.get('descripcion')        # opcional
        )
        db_sql.session.add(nueva_mascota)
        db_sql.session.commit()
        return jsonify({'mensaje': 'Mascota creada', 'id': nueva_mascota.id}), 201

    elif request.method == 'GET':
        mascotas = Mascota.query.all()
        return jsonify([{
            'id': m.id,
            'nombre': m.nombre,
            'tipo': m.tipo,
            'fecha_perdida': m.fecha_perdida,
            'descripcion': m.descripcion
        } for m in mascotas])

# Rutas adicionales...

if __name__ == '__main__':
    app.run(debug=True)
